<?php
//Modify constants with data needed to access your own database
define('DB_HOST','localhost');
define('DB_NAME','testdb');
define('DB_USER','testuser');
define('DB_PASSWORD','test');
?>