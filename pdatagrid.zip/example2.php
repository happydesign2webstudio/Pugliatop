<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Example 2 PDatagrid</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
<?php 
require 'pdatagrid.class.php';

//Establish a database connection
require 'dbconfig.php';
$conn = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD) or die('Connection to database failed: ' . mysql_error());
mysql_select_db(DB_NAME) or die ('select_db failed!');

//Initialize instance with database connection
$grid = new PDatagrid($conn);

//SQL queries to count/select records
$grid->setSqlCount("Select count(*) from composers");
$grid->setSqlSelect("Select name, date_format(date_birth,'%b %D %Y') db, 
date_format(date_death,'%b %D %Y') dd from composers");

//Base url for navigation links
$grid->baselink = 'example2.php';

//Maximum number of page navigation links
$grid->setMaxNavLinks(4);

//Rows (records) per page
$grid->setRowsPerPage(5);

//Set current page index
if(isset($_GET['page']))
	$grid->setPage($_GET['page']);
//Use unordered list to display records
$grid->rowfmt = "<ul%s>%s</ul>\n";
$grid->fieldfmt = "<li>%s</li>";
$grid->navfirst = 'First ';
$grid->navlast = ' Last';
$grid->navprev = 'Prev. ';
$grid->navnext = ' Next';
?>
<div>Unordered lists in place of a grid to show records</div>
<div><?php echo $grid->getRows(); ?></div>
<div id="navlinks"><?php echo $grid->getLinks();?></div>
<p style="font-size: 80%"><a href="http://www.webmastergate.com/">Webmastergate.com</a> - web development and web design tools and resources</p>
</body>
</html>