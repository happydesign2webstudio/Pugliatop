PDatagrid
Author: Massimo Giagnoni
http://www.webmastergate.com
Copyright 2007 - All rights reserved
License: GNU/GPL see license.txt

A php class to display records extracted by a SQL query in a grid-based format or other another customizable layout with page navigation links.

INSTALLATION
------------

Uncompress package in a directory of your webserver.

- docs/index.html contains detailed help on all class properties and methods

- example1.php and example2.php are code examples that demonstrate how to use the class. Before running them create a MySql database and execute the script in composers.sql to create the table used by examples. Modify dbconfig.php with host, db name, user and password needed to access your own database.

See also article at
http://www.webmastergate.com/php/paginate-query-results.html
