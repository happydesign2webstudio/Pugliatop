/-------------------------------------------------------------------------------
   COPYRIGHT AND DISCLAIMER
--------------------------------------------------------------------------------/

Solidres - A hotel booking extension for Joomla!
Copyright (C) 2013 - 2019 Solidres. All Rights Reserved.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

The full text of the license can be found in the LICENSE.txt file inside the full
package.


/-------------------------------------------------------------------------------
   CONTACT AND SUPPORT
--------------------------------------------------------------------------------/

To request quote for custom services

    Please see this page: http://solidres.com/services

To report bug

    Please use this forum: http://solidres.com/forum/categories/bugs

To request feature

    Please use this forum: http://solidres.com/forum/categories/feature-requests

To ask questions:

	http://solidres.com/forum/categories/questions


/-------------------------------------------------------------------------------
   DOCUMENTATION AND DOWNLOADS
--------------------------------------------------------------------------------/

Please check the online documentation

	http://solidres.com/documentation